// enter the number of vertices 
// 5
// enter the edges (u,v)
// 0 2
// enter 0 to add more edges
// 0
// enter the edges (u,v)
// 0 3
// enter 0 to add more edges
// 0
// enter the edges (u,v)
// 1 4
// enter 0 to add more edges
// 0
// enter the edges (u,v)
// 2 3
// enter 0 to add more edges
// 1
// adjacency list
// 0 -> 3 2 
// 1 -> 4 
// 2 -> 3 
// 3 -> 
// 4 -> 



#include<stdio.h>
#include<stdlib.h>

typedef struct node{
	int v;
	struct node* link;
}Node;

typedef struct list{
	int u;
	Node* link;
}List;



void main()
{
	int n;
	printf("enter the number of vertices \n");
	scanf("%d",&n);
	List *l = (List *)malloc(n*sizeof(List));
	for(int i=0;i<n;i++){
		l[i].u = i;
		l[i].link=NULL;
	}
	int c=0;

	while(c==0)
	{	int x,y;
		printf("enter the edges (u,v)\n");
		scanf("%d %d",&x,&y);
		Node* temp = (Node *)malloc(sizeof(Node));
		temp->v = y;
		temp->link = l[x].link;
		l[x].link = temp;
		printf("enter 0 to add more edges\n");
		scanf("%d",&c);
	}

	printf("adjacency list\n");
	Node *temp;
	for(int i=0;i<n;i++)
	{
		printf("%d -> ",l[i].u);
		temp = l[i].link;
		while(temp!=NULL)
		{
			printf("%d ",temp->v);
			temp=temp->link;
		}
		printf("\n");
	}

}