
#include<stdlib.h>
#include<stdio.h>
 

void merge(int *l,int ln,int *r,int rn,int *a){
    int i=0, j=0, k=0;
    while (i < ln && j < rn)
    {
        if (l[i] <= r[j])
        {
            a[k] = l[i];
            i++;
        }
        else
        {
            a[k] = r[j];
            j++;
        }
        k++;
    }
 
    while (i < ln)
    {
        a[k++] = l[i++];
    }
 
    while (j < rn)
    {
        a[k++] = r[j++];
    }
}
 

void mergeSort(int a[], int n)
{
    if(n<2)
        return;
    int m = n/2;
    int ln = m;
    int rn =n-m;
    int l[ln],r[rn];
    for(int i=0;i<m;i++)
    {
        l[i]=a[i];
    }   
    for(int i=m;i<n;i++)
    {
        r[i-m]=a[i];
    }
    mergeSort(l,ln);
    mergeSort(r,rn);
    merge(l,ln,r,rn, a);
    }
 

void printArray(int A[], int size)
{
    for (int i=0; i < size; i++)
        printf("%d ", A[i]);
    printf("\n");
}
 
int main()
{
    int arr[] = {12, 11, 13, 5, 6, 7};
 
    printf("Given array is \n");
    printArray(arr, 6);
 
    mergeSort(arr, 6);
 
    printf("\nSorted array is \n");
    printArray(arr, 6);
    return 0;
}