/* Bubble sort code */
 
#include <stdio.h>
 
void main()
{
  int array[100], n, i, j, temp;
 
  printf("Enter number of elements\n");
  scanf("%d", &n);
 
  printf("Enter %d integers\n", n);
 
  for (i = 0; i < n; i++)
    scanf("%d", &array[i]);

  for(i=0; i<n; i++) 
  { 
    int index_of_min = i; 
      
      for(int j=i; j<n; j++) 
      {            
        if(array[index_of_min]>array[j]) 
          {
            index_of_min = j;
          }
      }
    
    int temp = array[i]; 
    array[i] = array[index_of_min];     
    array[index_of_min] = temp; 
  } 
 
  printf("Sorted list in ascending order:\n");
 
  for ( i = 0 ; i < n ; i++ )
     printf("%d\n", array[i]);
 
}